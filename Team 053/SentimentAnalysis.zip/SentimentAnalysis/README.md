# Sentiment Analysis Project

This repository contains a Sentiment Analysis project with a Jupyter notebook, a trained model (`.pkl` file), and a Flask application (`app.py`).

## Project Structure

